from flask import Flask, render_template, jsonify
import serial
import threading
import time

app = Flask(__name__)

SERIAL_PORT = 'COM8'  # Ajuste conforme necessário
BAUDRATE = 115200

dados_sensor = {"tensao": 0, "ph": 0, "temperatura": 0}
historico_temp = []

def leitura_serial():
    global dados_sensor, historico_temp
    try:
        ser = serial.Serial(SERIAL_PORT, BAUDRATE, timeout=2)
        while True:
            linha = ser.readline().decode('utf-8').strip()
            if linha:
                try:
                    import json
                    dados = json.loads(linha)
                    dados_sensor = {
                        "tensao": dados.get("tensao", 0),
                        "ph": dados.get("ph", 0),
                        "temperatura": dados.get("temperatura", 0)
                    }
                    # Atualiza histórico da temperatura
                    historico_temp.append({
                        "timestamp": int(time.time() * 1000),  # timestamp JS (ms)
                        "temperatura": dados_sensor["temperatura"]
                    })
                    # Mantém apenas os últimos 2h (7200 amostras, se 1 por segundo)
                    if len(historico_temp) > 7200:
                        historico_temp = historico_temp[-7200:]
                except Exception:
                    pass
    except Exception as e:
        print("Falha ao abrir porta serial:", e)

t = threading.Thread(target=leitura_serial, daemon=True)
t.start()

@app.route("/")
def painel():
    return render_template("painel.html")

@app.route("/dados")
def dados():
    return jsonify(dados_sensor)

@app.route("/temperatura_historico")
def temperatura_historico():
    return jsonify(historico_temp)

if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)